
# Smart Campus Wellness Monitor

An AI-powered MERN stack web app that tracks student wellness and provides timely support.

## Features
- Daily mood & stress check-ins
- AI-based sentiment analysis
- Personalized wellness recommendations
- Counselor dashboard to view at-risk students
- Gamified wellness challenges

## Tech Stack
- Frontend: React.js
- Backend: Node.js + Express
- Database: MongoDB
- AI: Sentiment Analysis (NLP)

## Getting Started

### 1. Clone the repository
```bash
git clone https://github.com/your-username/smart-campus-wellness-monitor.git
```

### 2. Run Frontend
```bash
cd client
npm install
npm start
```

### 3. Run Backend
```bash
cd server
npm install
node server.js
```

## License
MIT
