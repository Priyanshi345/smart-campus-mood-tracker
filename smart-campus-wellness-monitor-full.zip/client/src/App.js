
import React, { useState } from 'react';
import './App.css';

function App() {
  const [mood, setMood] = useState('');
  const [response, setResponse] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:5000/api/mood', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mood })
    });
    const data = await res.json();
    setResponse(data);
  };

  return (
    <div className="App">
      <h1>Daily Mood Tracker</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={mood}
          onChange={(e) => setMood(e.target.value)}
          placeholder="How are you feeling today?"
        />
        <button type="submit">Submit</button>
      </form>
      {response && <p>{response.message}</p>}
    </div>
  );
}

export default App;
