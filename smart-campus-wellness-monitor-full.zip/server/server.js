
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const Sentiment = require('sentiment');

const app = express();
const sentiment = new Sentiment();

app.use(cors());
app.use(bodyParser.json());

app.post('/api/mood', (req, res) => {
  const { mood } = req.body;
  const result = sentiment.analyze(mood);
  const message = result.score < 0
    ? 'You seem stressed. Here are some wellness resources.'
    : 'Glad to hear you're doing well! Keep it up!';
  res.json({ score: result.score, message });
});

app.listen(5000, () => console.log('Server running on http://localhost:5000'));
